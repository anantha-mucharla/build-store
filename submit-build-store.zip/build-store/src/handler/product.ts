import express, { Request, Response } from 'express'
import { Product, ProductStore } from '../models/product'
import tokenVerify from '../middleware/authen'

const store = new ProductStore();


const create =createfunc;

const show =showfunc;

const index =indexfunc;

const ProductRoutes =ProductRoutesfunc;

function ProductRoutesfunc (app: express.Application){
    app.post('/products',tokenVerify, create)
    app.get('/products/:id',tokenVerify, show)

    app.get('/products', index)

}

async function indexfunc (_req: Request, res: Response) {
    try {
    const products = await store.index()
    res.json(products)
    } catch(err) {
        console.log(err)
        res.json(err)
    }
}

async function createfunc (_req: Request, res: Response){
    try {
        const product: Product = {
            name: _req.body.name,
            price: _req.body.price,
            category: _req.body.category ?? null
        }
        const newOrder = await store.create(product)

        res.json(newOrder)
    } catch(err) {
        console.log(err)
        res.json(err)
    }
}

async function showfunc (req: Request, res: Response) {
        const product = await store.show(req.params.id)
        res.json(product)
}

async function indexfunct (_req: Request, res: Response) {
    try {
    const products = await store.index()
    res.json(products)
    } catch(err) {
        console.log(err)
        res.json(err)
    }
}

export default ProductRoutes;