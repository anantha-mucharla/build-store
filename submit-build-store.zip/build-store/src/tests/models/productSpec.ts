import {Product, ProductStore} from '../../models/product';

import {User, UserStore} from '../../models/user';

const store = new UserStore();


const storep = new ProductStore();

describe('Product model', () => {
    it('should have index method', () => {
        expect(storep.index).toBeDefined();
    })

    it('should have show method', () => {
        expect(storep.show).toBeDefined();
    })

    it('should have create method', () => {
        expect(storep.create).toBeDefined();
    })

    it('create method should add 1 product', async() =>{
        const result = await storep.create({
            name: 'spoon',
            price: 10,
            category: 'utensil'
        })
        expect(result).toEqual({
            id:1,
            name: 'spoon',
            price: 10,
            category: 'utensil'
        });
    })

    it('index method should return list', async() => {
        const result = await storep.index();
        expect(result).toEqual([{
            id:1,
            name: 'spoon',
            price: 10,
            category: 'utensil'
        }])
    })

    it('show method should return single product', async () => {
        const result = await storep.show('1');
        expect(result).toEqual({
            id:1,
            name: 'spoon',
            price: 10,
            category: 'utensil'
        })
    })
})

describe('User model', () => {
    it('should have index method', () => {
        expect(store.index).toBeDefined();
    })

    it('should have show method', () => {
        expect(store.show).toBeDefined();
    })

    it('should have create method', () => {
        expect(store.create).toBeDefined();
    })

    it('create method should add 1 user', async() =>{
        const result = await store.create({
            username: 'user1',
            firstname: 'John',
            lastname: 'Smith',
            password: 'password123'
        })
        expect(result).toEqual({
            id:1,
            username: 'user1',
            firstname: 'John',
            lastname: 'Smith'
        });
    })

    it('index method should return list', async() => {
        const result = await store.index();
        expect(result).toEqual([{
            id:1,
            username: 'user1',
            firstname: 'John',
            lastname: 'Smith'
        }])
    })

    it('show method should return single user', async () => {
        const result = await store.show('1');
        expect(result).toEqual({
            id:1,
            username: 'user1',
            firstname: 'John',
            lastname: 'Smith'
        })
    })
})
